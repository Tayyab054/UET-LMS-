enum LmsPageCategory {
  auth,
  dashboard,
  verifications,
  downloads,
  support,
  blog,
  global,
}

class RouteClassifier {
  /// Maps incoming URL patterns to CSS Categories using Regex
  static LmsPageCategory classifyUrl(String url) {
    final uri = Uri.parse(url);
    final path = uri.path.toLowerCase();

    if (path.contains('/web/login') || path.contains('/web/reset_password')) {
      return LmsPageCategory.auth;
    }
    if (path.startsWith('/my') || path == '/' || path.contains('/home')) {
      return LmsPageCategory.dashboard;
    }
    if (path.contains('verify') || path.contains('alumni')) {
      return LmsPageCategory.verifications;
    }
    if (path.contains('download') || path.contains('attachment')) {
      return LmsPageCategory.downloads;
    }
    if (path.contains('support') || path.contains('contactus') || path.contains('help')) {
      return LmsPageCategory.support;
    }
    if (path.contains('blog') || path.contains('forum')) {
      return LmsPageCategory.blog;
    }

    return LmsPageCategory.global;
  }

  /// Map Category enum to exact asset file name
  static String getCssFileName(LmsPageCategory category) {
    switch (category) {
      case LmsPageCategory.auth:
        return 'auth.css';
      case LmsPageCategory.dashboard:
        return 'dashboard.css';
      case LmsPageCategory.verifications:
        return 'verifications.css';
      case LmsPageCategory.downloads:
        return 'downloads.css';
      case LmsPageCategory.support:
        return 'support.css';
      case LmsPageCategory.blog:
        return 'blog.css';
      case LmsPageCategory.global:
        return 'global.css';
    }
  }
}