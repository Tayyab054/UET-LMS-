import 'package:flutter/material.dart';
import 'views/lms_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const UetLmsApp());
}

class UetLmsApp extends StatelessWidget {
  const UetLmsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UET LMS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color(0xFF0056B3),
      ),
      home: const LmsScreen(),
    );
  }
}