import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class LmsScreen extends StatefulWidget {
  const LmsScreen({super.key});

  @override
  State<LmsScreen> createState() => _LmsScreenState();
}

class _LmsScreenState extends State<LmsScreen> {
  InAppWebViewController? _webViewController;
  bool _isPageReady = false;

  void _injectCustomEngine(InAppWebViewController controller) async {
    try {
      final globalCss = await rootBundle.loadString('assets/css/global.css');
      final authCss = await rootBundle.loadString('assets/css/auth.css');

      final combinedCss = (globalCss + "\n" + authCss)
          .replaceAll('\\', '\\\\')
          .replaceAll("'", "\\'")
          .replaceAll('\n', ' ');

      final String jsCode = '''
        (function() {
          // 1. Inject Style Tag
          var styleId = 'uet-lms-styles';
          var style = document.getElementById(styleId);
          if (!style) {
            style = document.createElement('style');
            style.id = styleId;
            style.type = 'text/css';
            style.appendChild(document.createTextNode('$combinedCss'));
            (document.head || document.documentElement).appendChild(style);
          } else {
            style.innerHTML = '$combinedCss';
          }

          // 2. Attach Password Eye Icon
          var pwdField = document.querySelector('input[type="password"], input[name="password"]');
          if (pwdField && !pwdField.getAttribute('data-eye-active')) {
            pwdField.setAttribute('data-eye-active', 'true');

            var parent = pwdField.parentElement;
            if (parent) {
              parent.classList.add('lms-pwd-group');

              var eyeBtn = document.createElement('span');
              eyeBtn.className = 'lms-eye-btn';
              eyeBtn.innerText = '👁️';

              eyeBtn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                if (pwdField.type === 'password') {
                  pwdField.type = 'text';
                  eyeBtn.innerText = '🙈';
                } else {
                  pwdField.type = 'password';
                  eyeBtn.innerText = '👁️';
                }
              };

              parent.appendChild(eyeBtn);
            }
          }
        })();
      ''';

      await controller.evaluateJavascript(source: jsCode);
    } catch (e) {
      debugPrint("Injection Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0056B3),
      body: SafeArea(
        child: Stack(
          children: [
            AnimatedOpacity(
              opacity: _isPageReady ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 250),
              child: InAppWebView(
                initialUrlRequest: URLRequest(url: WebUri('https://lms.uet.edu.pk/web/login')),
                initialSettings: InAppWebViewSettings(
                  javaScriptEnabled: true,
                  domStorageEnabled: true,
                  useWideViewPort: true,
                  loadWithOverviewMode: true,
                ),
                onWebViewCreated: (controller) => _webViewController = controller,
                onLoadStart: (controller, url) => _injectCustomEngine(controller),
                onProgressChanged: (controller, progress) {
                  _injectCustomEngine(controller);
                  if (progress > 60 && !_isPageReady) {
                    setState(() => _isPageReady = true);
                  }
                },
                onLoadStop: (controller, url) {
                  _injectCustomEngine(controller);
                  setState(() => _isPageReady = true);
                },
              ),
            ),
            if (!_isPageReady)
              Container(
                color: Colors.white,
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: Color(0xFF0056B3)),
                      SizedBox(height: 16),
                      Text('Loading LMS Portal...'),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}